-- ============================================================
-- HarOS Hub - Supabase Schema (Draft v1)
-- Jalankan di SQL Editor Supabase
-- ============================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ============================================================
-- 1. PROFILES
-- ============================================================
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text,
  full_name text,
  role text default 'staff' check (role in ('owner', 'manager', 'staff', 'accountant')),
  business_type text check (business_type in ('retail', 'fnb', 'jasa')),
  business_name text,
  onboarding_completed boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Auto create profile on signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, new.raw_user_meta_data->>'full_name');
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
-- 2. MODULES
-- ============================================================
create table if not exists public.modules (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  icon text,
  description text,
  suggested_for text[] default '{}',
  is_active boolean default true,
  created_at timestamptz default now()
);

-- Seed default modules
insert into public.modules (name, slug, icon, description, suggested_for) values
  ('POS', 'pos', 'shopping-cart', 'Transaksi penjualan & kasir', array['retail','fnb']),
  ('Gudang', 'gudang', 'warehouse', 'Manajemen stok & inventori', array['retail','fnb']),
  ('Sales', 'sales', 'trending-up', 'Penjualan, target & piutang', array['retail','fnb','jasa']),
  ('Staff', 'staff', 'users', 'Manajemen karyawan & absensi', array['retail','fnb','jasa']),
  ('Kas', 'kas', 'wallet', 'Kas masuk, keluar & pembukuan', array['retail','fnb','jasa']),
  ('Laporan', 'laporan', 'bar-chart', 'Laporan & analitik', array['retail','fnb','jasa'])
on conflict (slug) do nothing;

-- ============================================================
-- 3. USER MODULES (modul yang diaktifkan)
-- ============================================================
create table if not exists public.user_modules (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  module_id uuid references public.modules(id) on delete cascade,
  enabled boolean default true,
  created_at timestamptz default now(),
  unique(user_id, module_id)
);

-- ============================================================
-- 4. PRODUCTS
-- ============================================================
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  name text not null,
  sku text,
  barcode text,
  stock integer default 0,
  min_stock integer default 0,
  buy_price numeric(15,2) default 0,
  sell_price numeric(15,2) default 0,
  category text,
  unit text default 'pcs',
  is_active boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ============================================================
-- 5. TRANSACTIONS (POS)
-- ============================================================
create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  invoice_number text,
  customer_name text,
  subtotal numeric(15,2) default 0,
  discount numeric(15,2) default 0,
  tax numeric(15,2) default 0,
  total numeric(15,2) default 0,
  payment_method text default 'cash',
  status text default 'completed' check (status in ('draft','completed','cancelled')),
  notes text,
  created_at timestamptz default now()
);

-- ============================================================
-- 6. TRANSACTION ITEMS
-- ============================================================
create table if not exists public.transaction_items (
  id uuid primary key default gen_random_uuid(),
  transaction_id uuid references public.transactions(id) on delete cascade,
  product_id uuid references public.products(id),
  product_name text,
  qty integer default 1,
  price numeric(15,2) default 0,
  subtotal numeric(15,2) default 0,
  created_at timestamptz default now()
);

-- ============================================================
-- RLS POLICIES
-- ============================================================

-- Profiles
alter table public.profiles enable row level security;

create policy "Users can view own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- Modules (public read)
alter table public.modules enable row level security;

create policy "Anyone can view active modules"
  on public.modules for select
  using (is_active = true);

-- User Modules
alter table public.user_modules enable row level security;

create policy "Users manage own modules"
  on public.user_modules for all
  using (auth.uid() = user_id);

-- Products
alter table public.products enable row level security;

create policy "Users manage own products"
  on public.products for all
  using (auth.uid() = user_id);

-- Transactions
alter table public.transactions enable row level security;

create policy "Users manage own transactions"
  on public.transactions for all
  using (auth.uid() = user_id);

-- Transaction Items (via transaction ownership)
alter table public.transaction_items enable row level security;

create policy "Users manage own transaction items"
  on public.transaction_items for all
  using (
    exists (
      select 1 from public.transactions t
      where t.id = transaction_id and t.user_id = auth.uid()
    )
  );

-- ============================================================
-- INDEXES
-- ============================================================
create index if not exists idx_products_user on public.products(user_id);
create index if not exists idx_transactions_user on public.transactions(user_id);
create index if not exists idx_transactions_created on public.transactions(created_at desc);
create index if not exists idx_user_modules_user on public.user_modules(user_id);
