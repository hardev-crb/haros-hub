import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://rmkcefybmbaikuqkakzj.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJta2NlZnlibWJhaWh1cWtha3pqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTIwNzg4OTgsImV4cCI6MjEwNzY1NDg5OH0.5pQ_kXZsAtYfjoalso_DmVE6rGw9Thalp8CUeYMm1lc'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)