import type { Page } from '../App'

interface Props {
  onNavigate: (page: Page) => void
}

const modules: { name: string; desc: string; page: Page; locked: boolean }[] = [
  { name: 'POS', desc: 'Transaksi & Penjualan', page: 'pos', locked: false },
  { name: 'Gudang', desc: 'Stok & Inventori', page: 'gudang', locked: false },
  { name: 'Sales', desc: 'Penjualan & Target', page: 'sales', locked: true },
  { name: 'Staff', desc: 'Manajemen Karyawan', page: 'staff', locked: true },
  { name: 'Kas', desc: 'Kas & Pembukuan', page: 'launcher', locked: false },
  { name: 'Laporan', desc: 'Analitik & Laporan', page: 'launcher', locked: false },
]

export default function Launcher({ onNavigate }: Props) {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">H</div>
          <span className="font-semibold">HarOS Hub</span>
        </div>
        <div className="text-sm text-slate-500">Owner</div>
      </header>

      <main className="p-4 space-y-6">
        <section>
          <h2 className="font-semibold text-slate-800 mb-3">Dashboard Umum</h2>
          <div className="grid grid-cols-3 gap-3">
            <button className="bg-white p-3 rounded-xl border text-center text-sm active:bg-slate-50">Pengumuman</button>
            <button className="bg-white p-3 rounded-xl border text-center text-sm active:bg-slate-50">Top 10 Karyawan</button>
            <button className="bg-white p-3 rounded-xl border text-center text-sm active:bg-slate-50">Info Pasar</button>
          </div>
        </section>

        <section>
          <h2 className="font-semibold text-slate-800 mb-3">Modul Utama</h2>
          <div className="grid grid-cols-3 gap-3">
            {modules.map((m) => (
              <button
                key={m.name}
                onClick={() => !m.locked && onNavigate(m.page)}
                disabled={m.locked}
                className={`bg-white p-4 rounded-xl border text-center relative active:scale-95 ${
                  m.locked ? 'opacity-60' : ''
                }`}
              >
                {m.locked && (
                  <div className="absolute top-2 right-2 text-xs bg-slate-200 px-1.5 py-0.5 rounded">🔒</div>
                )}
                <div className="font-medium text-slate-900">{m.name}</div>
                <div className="text-xs text-slate-500 mt-1">{m.desc}</div>
              </button>
            ))}
          </div>
        </section>
      </main>
    </div>
  )
}