import { useState } from 'react'
import type { BusinessType } from '../types'

interface Props {
  onContinue: () => void
}

const businessTypes: { id: BusinessType; name: string; desc: string }[] = [
  { id: 'retail', name: 'Retail / Toko', desc: 'Kelola toko, stok, penjualan, dan pelanggan' },
  { id: 'fnb', name: 'F&B', desc: 'Kelola menu, pesanan, dapur, dan meja' },
  { id: 'jasa', name: 'Jasa', desc: 'Kelola layanan, klien, jadwal, dan tagihan' },
]

export default function Onboarding({ onContinue }: Props) {
  const [selected, setSelected] = useState<BusinessType | null>(null)

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl mx-auto mb-4 flex items-center justify-center text-white text-2xl font-bold">H</div>
          <h1 className="text-2xl font-bold text-slate-900">Selamat Datang di HarOS Hub</h1>
          <p className="text-slate-500 mt-2">Pilih jenis usaha Anda untuk memulai</p>
        </div>

        <div className="space-y-3">
          {businessTypes.map((bt) => (
            <button
              key={bt.id}
              onClick={() => setSelected(bt.id)}
              className={`w-full p-4 rounded-xl border-2 text-left transition active:scale-95 ${
                selected === bt.id
                  ? 'border-blue-600 bg-blue-50'
                  : 'border-slate-200 bg-white'
              }`}
            >
              <div className="font-semibold text-slate-900">{bt.name}</div>
              <div className="text-sm text-slate-500">{bt.desc}</div>
            </button>
          ))}
        </div>

        <button
          disabled={!selected}
          onClick={onContinue}
          className="w-full mt-6 py-3 rounded-xl bg-blue-600 text-white font-semibold disabled:opacity-50 active:bg-blue-700"
        >
          Lanjutkan
        </button>
      </div>
    </div>
  )
}