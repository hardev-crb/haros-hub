import { useState } from 'react'

interface Props {
  onBack?: () => void
}

interface CartItem {
  id: string
  name: string
  qty: number
  price: number
}

export default function POSTransaction({ onBack }: Props) {
  const [customer, setCustomer] = useState('')
  const [items, setItems] = useState<CartItem[]>([
    { id: '1', name: 'Kopi HarOS Original', qty: 1, price: 28000 },
    { id: '2', name: 'Teh HarOS Manis', qty: 2, price: 12000 },
  ])
  const [discount, setDiscount] = useState(0)

  const subtotal = items.reduce((sum, i) => sum + i.qty * i.price, 0)
  const total = subtotal - (subtotal * discount) / 100

  const updateQty = (id: string, delta: number) => {
    setItems(items.map(i => 
      i.id === id ? { ...i, qty: Math.max(1, i.qty + delta) } : i
    ))
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b px-4 py-3 flex items-center gap-3">
        <button onClick={onBack} className="text-slate-600 text-xl">←</button>
        <h1 className="font-semibold text-lg">Transaksi Baru</h1>
      </header>

      <main className="p-4 space-y-4">
        <div className="bg-white rounded-xl border p-4">
          <label className="text-sm font-medium text-slate-700">Pelanggan</label>
          <input
            type="text"
            placeholder="Nama pelanggan (opsional)"
            value={customer}
            onChange={(e) => setCustomer(e.target.value)}
            className="mt-1 w-full border rounded-lg px-3 py-2 text-sm"
          />
        </div>

        <div className="bg-white rounded-xl border p-4">
          <div className="flex justify-between items-center mb-3">
            <h2 className="font-medium">Item Produk</h2>
            <button className="text-sm text-blue-600">+ Tambah</button>
          </div>
          <div className="space-y-3">
            {items.map((item) => (
              <div key={item.id} className="flex items-center justify-between py-2 border-b last:border-0">
                <div>
                  <div className="font-medium text-sm">{item.name}</div>
                  <div className="text-xs text-slate-500">Rp {item.price.toLocaleString('id-ID')}</div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => updateQty(item.id, -1)} className="w-8 h-8 rounded border active:bg-slate-100">-</button>
                  <span className="w-6 text-center text-sm">{item.qty}</span>
                  <button onClick={() => updateQty(item.id, 1)} className="w-8 h-8 rounded border active:bg-slate-100">+</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border p-4 space-y-2">
          <div className="flex justify-between text-sm">
            <span>Subtotal</span>
            <span>Rp {subtotal.toLocaleString('id-ID')}</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span>Diskon (%)</span>
            <input
              type="number"
              value={discount}
              onChange={(e) => setDiscount(Number(e.target.value))}
              className="w-16 border rounded px-2 py-1 text-right text-sm"
            />
          </div>
          <div className="flex justify-between font-semibold text-lg pt-2 border-t">
            <span>Total</span>
            <span className="text-blue-600">Rp {total.toLocaleString('id-ID')}</span>
          </div>
        </div>

        <div className="flex gap-3">
          <button className="flex-1 py-3 rounded-xl border font-medium active:bg-slate-50">Simpan Draft</button>
          <button className="flex-1 py-3 rounded-xl bg-blue-600 text-white font-medium active:bg-blue-700">
            Proses Pembayaran
          </button>
        </div>
      </main>
    </div>
  )
}