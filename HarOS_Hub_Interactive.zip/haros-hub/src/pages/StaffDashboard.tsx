interface Props {
  onBack?: () => void
}

const stats = [
  { label: 'Total Karyawan', value: '128' },
  { label: 'Hadir Hari Ini', value: '96' },
  { label: 'Cuti', value: '8' },
]

const employees = [
  { name: 'Andi Pratama', role: 'Staff Marketing', status: 'Hadir', time: '08:55' },
  { name: 'Budi Santoso', role: 'Admin Operasional', status: 'Hadir', time: '09:02' },
  { name: 'Citra Dewi', role: 'Staff HR', status: 'Cuti', time: '-' },
  { name: 'Dian Nugroho', role: 'Staff IT', status: 'Hadir', time: '08:47' },
]

export default function StaffDashboard({ onBack }: Props) {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b px-4 py-4 flex items-center gap-2">
        {onBack && (
          <button onClick={onBack} className="text-slate-600 text-xl">←</button>
        )}
        <div>
          <h1 className="text-xl font-bold text-slate-900">Staff</h1>
          <p className="text-sm text-slate-500">Manajemen Karyawan</p>
        </div>
      </header>

      <main className="p-4 space-y-4">
        <div className="grid grid-cols-3 gap-3">
          {stats.map((s) => (
            <div key={s.label} className="bg-white rounded-xl border p-3 text-center">
              <div className="text-xs text-slate-500">{s.label}</div>
              <div className="font-bold text-xl text-slate-900">{s.value}</div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-xl border">
          <div className="px-4 py-3 border-b font-semibold">Daftar Karyawan</div>
          <div className="divide-y">
            {employees.map((e) => (
              <div key={e.name} className="px-4 py-3 flex justify-between items-center">
                <div>
                  <div className="text-sm font-medium">{e.name}</div>
                  <div className="text-xs text-slate-500">{e.role}</div>
                </div>
                <div className="text-right">
                  <div className={`text-xs font-medium ${e.status === 'Hadir' ? 'text-green-600' : 'text-orange-500'}`}>{e.status}</div>
                  <div className="text-xs text-slate-400">{e.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-xl border p-3">
            <div className="text-xs text-slate-500">Top Performer</div>
            <div className="font-medium text-sm mt-1">Andi Pratama</div>
            <div className="text-xs text-yellow-600">★ 4.9</div>
          </div>
          <div className="bg-white rounded-xl border p-3">
            <div className="text-xs text-slate-500">Suspended</div>
            <div className="font-medium text-sm mt-1">Fajar Hidayat</div>
            <div className="text-xs text-red-500">20 Mei</div>
          </div>
        </div>

        <button className="w-full py-3 rounded-xl bg-blue-600 text-white font-medium active:bg-blue-700">+ Tambah Karyawan</button>
      </main>
    </div>
  )
}