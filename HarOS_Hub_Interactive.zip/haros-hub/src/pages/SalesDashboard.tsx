interface Props {
  onBack?: () => void
}

const stats = [
  { label: 'Penjualan Bulan Ini', value: 'Rp 125.750.000', sub: '+18% vs bulan lalu' },
  { label: 'Target', value: '63%', sub: 'Rp 200jt' },
  { label: 'Piutang', value: 'Rp 32.450.000', sub: '12 invoice' },
]

const sales = [
  { id: 'SO-001', customer: 'PT Maju Bersama', total: 15750000, status: 'Selesai' },
  { id: 'SO-002', customer: 'CV Sejahtera', total: 8900000, status: 'Menunggu' },
  { id: 'SO-003', customer: 'UD Sumber Rezeki', total: 6450000, status: 'Selesai' },
]

export default function SalesDashboard({ onBack }: Props) {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b px-4 py-4 flex items-center gap-2">
        {onBack && (
          <button onClick={onBack} className="text-slate-600 text-xl">←</button>
        )}
        <div>
          <h1 className="text-xl font-bold text-slate-900">Sales</h1>
          <p className="text-sm text-slate-500">Penjualan & Target</p>
        </div>
      </header>

      <main className="p-4 space-y-4">
        <div className="grid grid-cols-1 gap-3">
          {stats.map((s) => (
            <div key={s.label} className="bg-white rounded-xl border p-4 flex justify-between items-center">
              <div>
                <div className="text-sm text-slate-500">{s.label}</div>
                <div className="font-bold text-lg text-slate-900">{s.value}</div>
              </div>
              <div className="text-xs text-slate-400">{s.sub}</div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-xl border">
          <div className="px-4 py-3 border-b font-semibold">Penjualan Terbaru</div>
          <div className="divide-y">
            {sales.map((s) => (
              <div key={s.id} className="px-4 py-3 flex justify-between items-center">
                <div>
                  <div className="text-sm font-medium">{s.id}</div>
                  <div className="text-xs text-slate-500">{s.customer}</div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-sm">Rp {s.total.toLocaleString('id-ID')}</div>
                  <div className={`text-xs ${s.status === 'Selesai' ? 'text-green-600' : 'text-orange-500'}`}>{s.status}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-3">
          <button className="flex-1 py-3 rounded-xl bg-blue-600 text-white font-medium active:bg-blue-700">Buat Penawaran</button>
          <button className="flex-1 py-3 rounded-xl border font-medium active:bg-slate-50">Lihat Laporan</button>
        </div>
      </main>
    </div>
  )
}