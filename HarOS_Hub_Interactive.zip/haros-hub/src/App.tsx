import { useState } from 'react'
import Onboarding from './pages/Onboarding'
import Launcher from './pages/Launcher'
import POSDashboard from './pages/POSDashboard'
import POSTransaction from './pages/POSTransaction'
import GudangDashboard from './pages/GudangDashboard'
import SalesDashboard from './pages/SalesDashboard'
import StaffDashboard from './pages/StaffDashboard'

export type Page = 'onboarding' | 'launcher' | 'pos' | 'pos-tx' | 'gudang' | 'sales' | 'staff'

function App() {
  const [page, setPage] = useState<Page>('onboarding')

  const navigate = (p: Page) => setPage(p)

  return (
    <div className="min-h-screen pb-20 bg-slate-50">
      {page === 'onboarding' && <Onboarding onContinue={() => navigate('launcher')} />}
      {page === 'launcher' && <Launcher onNavigate={navigate} />}
      {page === 'pos' && <POSDashboard onBack={() => navigate('launcher')} onNewTx={() => navigate('pos-tx')} />}
      {page === 'pos-tx' && <POSTransaction onBack={() => navigate('pos')} />}
      {page === 'gudang' && <GudangDashboard onBack={() => navigate('launcher')} />}
      {page === 'sales' && <SalesDashboard onBack={() => navigate('launcher')} />}
      {page === 'staff' && <StaffDashboard onBack={() => navigate('launcher')} />}

      {/* Bottom Navigation - lebih besar untuk HP */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg z-50">
        <div className="flex justify-around py-2 px-1">
          <button onClick={() => navigate('onboarding')} className="flex flex-col items-center px-2 py-1 text-xs active:bg-slate-100 rounded">
            <span className="text-lg">🏠</span>
            <span>Onboard</span>
          </button>
          <button onClick={() => navigate('launcher')} className="flex flex-col items-center px-2 py-1 text-xs active:bg-slate-100 rounded">
            <span className="text-lg">📱</span>
            <span>Home</span>
          </button>
          <button onClick={() => navigate('pos')} className="flex flex-col items-center px-2 py-1 text-xs active:bg-slate-100 rounded">
            <span className="text-lg">🛒</span>
            <span>POS</span>
          </button>
          <button onClick={() => navigate('gudang')} className="flex flex-col items-center px-2 py-1 text-xs active:bg-slate-100 rounded">
            <span className="text-lg">📦</span>
            <span>Gudang</span>
          </button>
          <button onClick={() => navigate('sales')} className="flex flex-col items-center px-2 py-1 text-xs active:bg-slate-100 rounded">
            <span className="text-lg">📈</span>
            <span>Sales</span>
          </button>
          <button onClick={() => navigate('staff')} className="flex flex-col items-center px-2 py-1 text-xs active:bg-slate-100 rounded">
            <span className="text-lg">👥</span>
            <span>Staff</span>
          </button>
        </div>
      </div>
    </div>
  )
}

export default App