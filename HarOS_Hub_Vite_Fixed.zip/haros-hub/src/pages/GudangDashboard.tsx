interface Props {
  onBack?: () => void
}

const stats = [
  { label: 'Total Barang', value: '1.248', sub: 'Semua barang' },
  { label: 'Stok Rendah', value: '32', sub: 'Perlu perhatian', alert: true },
  { label: 'Barang Masuk', value: '18', sub: 'Hari ini' },
]

const movements = [
  { type: 'Masuk', name: 'Kopi Original', qty: '+20', time: '09:15' },
  { type: 'Keluar', name: 'Teh Manis', qty: '-5', time: '08:42' },
  { type: 'Masuk', name: 'Snack Pedas', qty: '+15', time: '08:10' },
]

export default function GudangDashboard({ onBack }: Props) {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b px-4 py-4 flex items-center gap-3 sticky top-0">
        {onBack && (
          <button onClick={onBack} className="text-slate-600 text-xl">←</button>
        )}
        <div>
          <h1 className="text-xl font-bold text-slate-900">Gudang</h1>
          <p className="text-sm text-slate-500">Manajemen Stok</p>
        </div>
      </header>

      <main className="p-4 space-y-4">
        <div className="grid grid-cols-3 gap-3">
          {stats.map((s) => (
            <div key={s.label} className={`bg-white rounded-2xl border p-3 shadow-sm ${s.alert ? 'border-orange-200 bg-orange-50' : ''}`}>
              <div className="text-xs text-slate-500">{s.label}</div>
              <div className={`font-bold text-lg ${s.alert ? 'text-orange-600' : 'text-slate-900'}`}>{s.value}</div>
              <div className="text-xs text-slate-400">{s.sub}</div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl border shadow-sm">
          <div className="px-4 py-3 border-b font-semibold text-sm">Pergerakan Stok Terakhir</div>
          <div className="divide-y">
            {movements.map((m, i) => (
              <div key={i} className="px-4 py-3 flex justify-between items-center">
                <div>
                  <div className="text-sm font-medium">{m.name}</div>
                  <div className="text-xs text-slate-500">{m.type}</div>
                </div>
                <div className="text-right">
                  <div className={`font-medium text-sm ${m.qty.startsWith('+') ? 'text-green-600' : 'text-red-500'}`}>{m.qty}</div>
                  <div className="text-xs text-slate-400">{m.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-3">
          <button className="flex-1 py-3.5 rounded-2xl bg-blue-600 text-white font-medium active:bg-blue-700">+ Tambah Barang</button>
          <button className="flex-1 py-3.5 rounded-2xl border font-medium active:bg-slate-50">Opname Stok</button>
        </div>
      </main>
    </div>
  )
}