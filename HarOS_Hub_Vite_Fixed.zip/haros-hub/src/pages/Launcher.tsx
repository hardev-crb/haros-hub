import type { Page } from '../App'

interface Props {
  onNavigate: (page: Page) => void
}

const modules: { name: string; desc: string; page: Page; locked: boolean; icon: string }[] = [
  { name: 'POS', desc: 'Transaksi & Penjualan', page: 'pos', locked: false, icon: '🛒' },
  { name: 'Gudang', desc: 'Stok & Inventori', page: 'gudang', locked: false, icon: '📦' },
  { name: 'Sales', desc: 'Penjualan & Target', page: 'sales', locked: true, icon: '📈' },
  { name: 'Staff', desc: 'Manajemen Karyawan', page: 'staff', locked: true, icon: '👥' },
  { name: 'Kas', desc: 'Kas & Pembukuan', page: 'launcher', locked: false, icon: '💰' },
  { name: 'Laporan', desc: 'Analitik & Laporan', page: 'launcher', locked: false, icon: '📊' },
]

export default function Launcher({ onNavigate }: Props) {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b px-4 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold">H</div>
          <div>
            <div className="font-semibold text-slate-900">HarOS Hub</div>
            <div className="text-xs text-slate-500">Owner</div>
          </div>
        </div>
      </header>

      <main className="p-4 space-y-6">
        <section>
          <h2 className="font-semibold text-slate-800 mb-3 text-sm uppercase tracking-wide">Dashboard Umum</h2>
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white p-4 rounded-2xl border text-center shadow-sm">
              <div className="text-2xl mb-1">📢</div>
              <div className="text-xs font-medium text-slate-700">Pengumuman</div>
            </div>
            <div className="bg-white p-4 rounded-2xl border text-center shadow-sm">
              <div className="text-2xl mb-1">🏆</div>
              <div className="text-xs font-medium text-slate-700">Top 10</div>
            </div>
            <div className="bg-white p-4 rounded-2xl border text-center shadow-sm">
              <div className="text-2xl mb-1">💹</div>
              <div className="text-xs font-medium text-slate-700">Info Pasar</div>
            </div>
          </div>
        </section>

        <section>
          <h2 className="font-semibold text-slate-800 mb-3 text-sm uppercase tracking-wide">Modul Utama</h2>
          <div className="grid grid-cols-3 gap-3">
            {modules.map((m) => (
              <button
                key={m.name}
                onClick={() => !m.locked && onNavigate(m.page)}
                disabled={m.locked}
                className={`bg-white p-4 rounded-2xl border text-center relative shadow-sm active:scale-95 transition ${
                  m.locked ? 'opacity-50' : ''
                }`}
              >
                {m.locked && (
                  <div className="absolute top-2 right-2 text-xs bg-slate-100 px-1.5 py-0.5 rounded-full">🔒</div>
                )}
                <div className="text-3xl mb-2">{m.icon}</div>
                <div className="font-medium text-slate-900 text-sm">{m.name}</div>
                <div className="text-xs text-slate-500 mt-0.5">{m.desc}</div>
              </button>
            ))}
          </div>
        </section>
      </main>
    </div>
  )
}