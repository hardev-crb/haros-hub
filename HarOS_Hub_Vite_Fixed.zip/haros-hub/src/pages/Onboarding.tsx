import { useState } from 'react'
import type { BusinessType } from '../types'

interface Props {
  onContinue: () => void
}

const businessTypes: { id: BusinessType; name: string; desc: string; icon: string }[] = [
  { id: 'retail', name: 'Retail / Toko', desc: 'Kelola toko, stok, penjualan, dan pelanggan', icon: '🏪' },
  { id: 'fnb', name: 'F&B', desc: 'Kelola menu, pesanan, dapur, dan meja', icon: '🍽️' },
  { id: 'jasa', name: 'Jasa', desc: 'Kelola layanan, klien, jadwal, dan tagihan', icon: '🛠️' },
]

export default function Onboarding({ onContinue }: Props) {
  const [selected, setSelected] = useState<BusinessType | null>(null)

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-blue-600 rounded-3xl mx-auto mb-5 flex items-center justify-center text-white text-3xl font-bold shadow-lg">H</div>
          <h1 className="text-2xl font-bold text-slate-900">Selamat Datang di HarOS Hub</h1>
          <p className="text-slate-500 mt-2 text-sm">Pilih jenis usaha Anda untuk memulai</p>
        </div>

        <div className="space-y-3">
          {businessTypes.map((bt) => (
            <button
              key={bt.id}
              onClick={() => setSelected(bt.id)}
              className={`w-full p-4 rounded-2xl border-2 text-left transition-all active:scale-[0.98] flex items-center gap-4 ${
                selected === bt.id
                  ? 'border-blue-600 bg-blue-50 shadow-md'
                  : 'border-slate-200 bg-white'
              }`}
            >
              <div className="text-3xl">{bt.icon}</div>
              <div>
                <div className="font-semibold text-slate-900">{bt.name}</div>
                <div className="text-sm text-slate-500 mt-0.5">{bt.desc}</div>
              </div>
            </button>
          ))}
        </div>

        <button
          disabled={!selected}
          onClick={onContinue}
          className="w-full mt-8 py-4 rounded-2xl bg-blue-600 text-white font-semibold text-lg disabled:opacity-40 active:bg-blue-700 shadow-lg"
        >
          Lanjutkan
        </button>
      </div>
    </div>
  )
}