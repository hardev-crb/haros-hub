interface Props {
  onBack?: () => void
  onNewTx?: () => void
}

const stats = [
  { label: 'Omzet Hari Ini', value: 'Rp 2.450.000', change: '+18%' },
  { label: 'Transaksi', value: '128', change: '+12%' },
  { label: 'Stok Menipis', value: '7', change: 'Perlu dicek' },
]

const recentTx = [
  { id: 'TRX-001', time: '09:38', total: 125000, status: 'Selesai' },
  { id: 'TRX-002', time: '09:21', total: 87500, status: 'Selesai' },
  { id: 'TRX-003', time: '09:07', total: 210000, status: 'Pending' },
]

export default function POSDashboard({ onBack, onNewTx }: Props) {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-5">
        <div className="flex items-center gap-3 mb-2">
          {onBack && (
            <button onClick={onBack} className="text-white text-xl">←</button>
          )}
          <div className="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center font-bold">H</div>
          <span className="font-semibold">HarOS Hub</span>
        </div>
        <h1 className="text-2xl font-bold">POS</h1>
        <p className="text-blue-100 text-sm">Point of Sales</p>
      </header>

      <main className="p-4 space-y-4">
        <div className="grid grid-cols-3 gap-3">
          {stats.map((s) => (
            <div key={s.label} className="bg-white rounded-2xl border p-3 shadow-sm">
              <div className="text-xs text-slate-500">{s.label}</div>
              <div className="font-bold text-slate-900 mt-1 text-sm">{s.value}</div>
              <div className="text-xs text-green-600 mt-1">{s.change}</div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl border shadow-sm">
          <div className="px-4 py-3 border-b flex justify-between items-center">
            <h2 className="font-semibold text-sm">Transaksi Terakhir</h2>
            <button className="text-sm text-blue-600">Lihat Semua</button>
          </div>
          <div className="divide-y">
            {recentTx.map((tx) => (
              <div key={tx.id} className="px-4 py-3 flex justify-between items-center">
                <div>
                  <div className="font-medium text-sm">{tx.id}</div>
                  <div className="text-xs text-slate-500">{tx.time}</div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-sm">Rp {tx.total.toLocaleString('id-ID')}</div>
                  <div className={`text-xs ${tx.status === 'Selesai' ? 'text-green-600' : 'text-orange-500'}`}>
                    {tx.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <button 
          onClick={onNewTx}
          className="w-full py-4 rounded-2xl bg-blue-600 text-white font-semibold text-lg active:bg-blue-700 shadow-lg"
        >
          + Transaksi Baru
        </button>
      </main>
    </div>
  )
}